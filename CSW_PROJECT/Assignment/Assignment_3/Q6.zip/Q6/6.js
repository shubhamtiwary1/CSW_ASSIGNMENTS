let a = 0;
$("#btn1").click(function(){
    $("#tbd").append('<tr id="row' + a + '"><td>Row ' + a++ + '</td></tr>');
});
$("#tbd").dblclick(function(){
    $(this).css({"color":"red"});
});
$("#btn").click(function(){
    let a = ("#inp").val();
    console.log(a);
    let id = '#row '+a;
    console.log(id);
    $(id).remove();  
});